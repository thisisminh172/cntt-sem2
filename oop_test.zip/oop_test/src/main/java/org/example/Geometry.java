/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.example;

/**
 *
 * @author minh-user
 */
public abstract class Geometry {
    abstract void input();
    abstract void output();
    abstract boolean isValid();
    abstract void perimeterCalculate();
    abstract void areaCalculate();
}
