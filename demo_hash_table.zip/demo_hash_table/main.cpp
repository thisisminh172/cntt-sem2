#include <iostream>

using namespace std;

const int Size = 5;
// Buoc 1
struct Node {
    int data;
    Node* pNext;
};

// Buoc 2
Node* initNode(int value) {
    Node* p = new Node;
    p->data = value;
    p->pNext = NULL;

    return p;
}

// Buoc 3
struct Bucket {
    Node* pHead;
    Node* pTail;
};

// Buoc 4
void initBucket(Bucket& bk) {
    bk.pHead = bk.pTail = NULL;
}

struct HashTable {
    Bucket buckets[Size];
};

void initHashTable(HashTable& h) {
    for(int i = 0; i < Size; i++) {
        // h.buckets[i].pHead = NULL;
        // h.buckets[i].pTail = NULL;
        initBucket(h.buckets[i]);
    }
}

// Ham nay lay dia chi
int hashFunc(int value) {
    return value % Size;
}

void addBucket(Bucket& b, Node* p) {

    if(b.pHead == NULL) {
        b.pHead = p;
        b.pTail = p;
    }else {
        b.pTail->pNext = p;
        b.pTail = p;
    }
}

// add value to hash table
void add(HashTable& h, Node* p) {
    int i = hashFunc(p->data);
    addBucket(h.buckets[i], p);
}

void add(HashTable& h, int value) {
    int i = hashFunc(value);

    Node* p = initNode(value);

    addBucket(h.buckets[i], p);
}

void printHashTable(HashTable h) {
    for(int i = 0; i < Size; i++) {
        cout << "Bucket[" << i << "] = ";
        for(Node* p = h.buckets[i].pHead; p != NULL; p=p->pNext) {
            cout << p->data << " ";
        }
        cout << endl;
    }
    cout << endl;
}

/** Viet ham tao du lieu cho bang bam tu mang 1 chieu
    input:
    - h: HashTable
    - arr: int[]
    - n: int
    output:
    - h: da thay doi => &
*/
void initHashTableArray(HashTable& h, int arr[], int n) {
    for(int i = 0; i < n; i++) {
        add(h, arr[i]);
    }
}

/** Viet ham tim 1 gia tri trong bang bam
    input:
    - h: HashTable
    - value: int
    output:
    - true/false (bool)
*/
bool tim(HashTable h, int value) {
    int i = hashFunc(value);

    for (Node* p = h.buckets[i].pHead ; p != NULL; p = p->pNext) {
        if (value == p->data) {
            return true;
        }
    }
    return false;

}

/** Viet ham
    input:
    -
    output:
    -
*/

/** Viet ham
    input:
    -
    output:
    -
*/

/** Viet ham
    input:
    -
    output:
    -
*/

int main()
{
    // Mang cac so nguyen
    //int a[10];
    //Bucket buckets[10];


    HashTable h;
    initHashTable(h);

    Node* p1 = initNode(50);
    Node* p2 = initNode(73);
    Node* p3 = initNode(35);

    add(h, p1);
    add(h, p2);
    add(h, p3);
    add(h, 56);
    add(h, 78);
    add(h, 56);
    add(h, 78);

    printHashTable(h);

    int a[] = {10, 56, 34, 89, 56, 12, 78, 45};
    int n = 8;
    initHashTableArray(h, a, n);
    printHashTable(h);

    cout << "Tim 30. Ket qua = " << tim(h, 30) << endl;
    cout << "Tim 89. Ket qua = " << tim(h, 89) << endl;
    return 0;
}
