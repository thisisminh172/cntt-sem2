/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ooptest;

/**
 *
 * @author minh-user
 */
public class LineSegment {
    private Point a;
    private Point b;
    
    public LineSegment(Point a, Point b) {
        this.a = a;
        this.b = b;
    }

    public LineSegment() {
    }

    public Point getA() {
        return a;
    }

    public void setA(Point a) {
        this.a = a;
    }

    public Point getB() {
        return b;
    }

    public void setB(Point b) {
        this.b = b;
    }
    
    public double length() {
        double value = Math.sqrt(Math.pow(this.a.getX() - this.b.getX(), 2) + Math.pow(this.a.getY()- this.b.getY(), 2));
        return value;
    }

    public void input() {
        System.out.println("Please enter x1 and y1 for point a: ");
    }

    public void output() {
    }

    
}
