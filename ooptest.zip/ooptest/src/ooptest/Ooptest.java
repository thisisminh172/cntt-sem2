/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ooptest;

/**
 *
 * @author minh-user
 */
public class Ooptest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Point temp = new Point();
        temp.input();
//        temp.output();
    }
    
}
